document.addEventListener('DOMContentLoaded', function() {
    const apiUrl = 'https://api.open-meteo.com/v1/forecast?latitude=60.1695&longitude=24.9354&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=Europe%2FBerlin&past_days=30&forecast_days=0';

    // Function to fetch data from the API and populate the view
    function fetchDataAndPopulateView(parameter, elementId) {
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                // Fetch data for statistical calculations from the previous 7 days (168 hours)
                const last7DaysData = data.hourly[parameter].slice(-168);

                // Calculate statistical measures
                const mean = calculateMean(last7DaysData);
                const median = calculateMedian(last7DaysData);
                const mode = calculateMode(last7DaysData);
                const range = calculateRange(last7DaysData);
                const stdDev = calculateStandardDeviation(last7DaysData);
                const min = Math.min(...last7DaysData);
                const max = Math.max(...last7DaysData);

                // Display statistical information for view2.html
                document.getElementById('mean-humidity').textContent = mean.toFixed(2);
                document.getElementById('median-humidity').textContent = median.toFixed(2);
                document.getElementById('mode-humidity').textContent = mode.toFixed(2);
                document.getElementById('range-humidity').textContent = range.toFixed(2);
                document.getElementById('std-dev-humidity').textContent = stdDev.toFixed(2);
                document.getElementById('min-humidity').textContent = min.toFixed(2);
                document.getElementById('max-humidity').textContent = max.toFixed(2);
                

                // Chart Creation
                const last20Data = data.hourly[parameter].slice(-20);
                populateView(last20Data, elementId); // Populate list of values
                if (parameter === 'relative_humidity_2m') {
                    createHumidityChart(last20Data, elementId); // Create humidity chart
                } else if (parameter === 'wind_speed_10m') {
                    createWindSpeedChart(last20Data, elementId); // Create wind speed chart
                } else {
                    createDefaultChart(last20Data, elementId); // Create default chart for other parameters
                }
            })
            .catch(error => console.error(`Error fetching ${parameter} data:`, error));
    }

    // Calculate the mean (average) of an array of values
    function calculateMean(data) {
        const sum = data.reduce((acc, value) => acc + value, 0);
        return sum / data.length;
    }

    // Calculate the median of an array of values
    function calculateMedian(data) {
        const sortedData = data.slice().sort((a, b) => a - b);
        const middleIndex = Math.floor(sortedData.length / 2);
        return sortedData.length % 2 === 0
            ? (sortedData[middleIndex - 1] + sortedData[middleIndex]) / 2
            : sortedData[middleIndex];
    }

    // Calculate the mode (most frequent value) of an array of values
    function calculateMode(data) {
        // Implement your mode calculation logic here
        // You can use an object to count occurrences of each value
        // and find the one with the highest count
        // For simplicity, I'll return the first value in the array
        return data[0];
    }

    // Calculate the range (difference between max and min) of an array of values
    function calculateRange(data) {
        return Math.max(...data) - Math.min(...data);
    }

    // Calculate the standard deviation of an array of values
    function calculateStandardDeviation(data) {
        const mean = calculateMean(data);
        const squaredDifferencesSum = data.reduce((acc, value) => acc + (value - mean) ** 2, 0);
        const variance = squaredDifferencesSum / data.length;
        return Math.sqrt(variance);
    }

    // Function to populate the view with the fetched data
    function populateView(data, elementId) {
        const valuesContainer = document.getElementById(elementId);
        if (valuesContainer) {
            valuesContainer.innerHTML = ''; // Clear previous data
            data.forEach(value => {
                const valueElement = document.createElement('div');
                valueElement.textContent = value.toString();
                valuesContainer.appendChild(valueElement);
            });
        }
    }    

    // Function to create realtive humidity chart
    function createHumidityChart(data, elementId) {
        const ctx = document.getElementById(elementId).getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from(Array(20).keys()), // Labels for the x-axis (0 to 19)
                datasets: [{
                    label: 'Relative Humidity (%)',
                    data: data,
                    backgroundColor: 'rgb(54, 162, 255)',
                    borderColor: 'rgb(54, 162, 255)',
                    borderWidth: 4,
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Relative Humidity (%)'
                        }
                    }
                }
            }
        });
    }

    // Call the function to fetch data and populate the view for relative humidity
    
    fetchDataAndPopulateView('relative_humidity_2m', 'humidity-values');
    fetchDataAndPopulateView('relative_humidity_2m', 'humidity-chart');
});
