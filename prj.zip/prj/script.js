document.addEventListener('DOMContentLoaded', function() {
    const apiUrl = 'https://api.open-meteo.com/v1/forecast?latitude=60.1695&longitude=24.9354&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=Europe%2FBerlin&past_days=30&forecast_days=0';

  // Function to fetch data from the API and populate the view
  function fetchDataAndPopulateView(parameter, elementId) {
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        // Fetch data for statistical calculations from the previous 7 days (168 hours)
        // const last7DaysData = data.hourly[parameter].slice(-168);

        // // Calculate statistical measures
        // const mean = calculateMean(last7DaysData);
        // const median = calculateMedian(last7DaysData);
        // const mode = calculateMode(last7DaysData);
        // const range = calculateRange(last7DaysData);
        // const stdDev = calculateStandardDeviation(last7DaysData);
        // const min = Math.min(...last7DaysData);
        // const max = Math.max(...last7DaysData);

        // // Display statistical information for view2.html
        // document.getElementById("mean-wind-speed").textContent = mean.toFixed(2);
        // document.getElementById("median-wind-speed").textContent =
        //   median.toFixed(2);
        // document.getElementById("mode-wind-speed").textContent = mode.toFixed(2);
        // document.getElementById("range-wind-speed").textContent =
        //   range.toFixed(2);
        // document.getElementById("std-dev-wind-speed").textContent =
        //   stdDev.toFixed(2);
        // document.getElementById("min-wind-speed").textContent = min.toFixed(2);
        // document.getElementById("max-wind-speed").textContent = max.toFixed(2);

        const last20Data = data.hourly[parameter].slice(-20);
        populateView(last20Data, elementId); // Populate list of values
        if (parameter === "relative_humidity_2m") {
          createHumidityChart(last20Data, elementId); // Create humidity chart
        } else if (parameter === "wind_speed_10m") {
          createWindSpeedChart(last20Data, elementId); // Create wind speed chart
        } else {
          createDefaultChart(last20Data, elementId); // Create default chart for other parameters
        }
      })
      .catch((error) =>
        console.error(`Error fetching ${parameter} data:`, error)
      );
  }

  // Function to populate the view with the fetched data
  function populateView(data, elementId) {
    const valuesContainer = document.getElementById(elementId);
    if (valuesContainer) {
      valuesContainer.innerHTML = ""; // Clear previous data
      data.forEach((value) => {
        const valueElement = document.createElement("div");
        valueElement.textContent = value.toString();
        valuesContainer.appendChild(valueElement);
      });
    }
  }
  
  // Function to create realtive humidity chart
  function createHumidityChart(data, elementId) {
    const ctx = document.getElementById(elementId).getContext("2d");
    const chart = new Chart(ctx, {
      type: "line",
      data: {
        labels: Array.from(Array(20).keys()), // Labels for the x-axis (0 to 19)
        datasets: [
          {
            label: "Relative Humidity (%)",
            data: data,
            backgroundColor: "rgb(54, 162, 255)",
            borderColor: "rgb(54, 162, 255)",
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Relative Humidity (%)",
            },
          },
        },
      },
    });
  }

  // Function to create wind speed chart
  function createWindSpeedChart(data, elementId) {
    const ctx = document.getElementById(elementId).getContext("2d");
    const chart = new Chart(ctx, {
      type: "line",
      data: {
        labels: Array.from(Array(20).keys()), // Labels for the x-axis (0 to 19)
        datasets: [
          {
            label: "Wind Speed (km/h)",
            data: data,
            backgroundColor: "rgba(255, 99, 132, 0.2)",
            borderColor: "rgba(255, 99, 132, 1)",
            borderWidth: 4,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Wind Speed (km/h)",
            },
          },
        },
      },
    });
  }

  // Fetch and populate data for each parameter
  fetchDataAndPopulateView("temperature_2m", "temperature-values");
  fetchDataAndPopulateView("relative_humidity_2m", "humidity-values");
  fetchDataAndPopulateView("wind_speed_10m", "wind-speed-values");
  fetchDataAndPopulateView("relative_humidity_2m", "humidity-chart");
  fetchDataAndPopulateView("wind_speed_10m", "wind-speed-chart");
});
